# Sweet Chantonia 
## Name
Chantel's bakery treats e-commerce site

## Description
Easy goto website for automated order-making processes for anyone looking to buy of Chantel's tasty baked treats. 


## Usage
Simple as login, basked your orders, proceed to checkout and then done.

## Support
email this address for support nicholasmavundlha7@gmail.com


## Contributing
Currently not accepting any contributions.

## Authors and acknowledgment
I would like to honor my dear buddy Tshepiso Malesa for the great hand he's played in the building of this project.


## Project status
Pending response...
