<?php
    // logout
    header("Location: ../index.html");
    exit;
     
?>